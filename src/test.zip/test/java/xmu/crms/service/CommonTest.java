package xmu.crms.service;

import org.junit.Test;

import java.util.Date;

import static java.lang.System.*;

/**
 * @author mads
 * @date 2017/12/21 21:21
 */
public class CommonTest {
    @Test
    public void test(){
        System.out.println(new Date().getTime());
    }
}
